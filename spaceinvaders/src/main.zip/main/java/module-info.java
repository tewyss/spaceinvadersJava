module spaceinvaders {
	requires transitive javafx.controls;
	requires javafx.fxml;
	requires javafx.base;
	requires javafx.media;
	requires jakarta.json.bind;
	requires jakarta.json;
	requires spaceinvaders.storage;
	requires java.logging;
	requires org.apache.logging.log4j;
	requires static lombok;
	requires org.slf4j;
	requires com.h2database;
	requires jakarta.persistence;
	requires org.hibernate.orm.core;

	opens spaceinvaders to javafx.fxml;

	exports spaceinvaders;
}