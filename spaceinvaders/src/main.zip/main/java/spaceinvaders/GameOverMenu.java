package spaceinvaders;

import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class GameOverMenu extends BaseMenu {
    public GameOverMenu(Font font, int currentScore) {
        
        addTitle("GAME OVER", font, Color.RED);
        addScore("Your Score", currentScore, font);
        askPlayerNameAndSaveScore(currentScore);

        createMenuItem("RETRY", font);
        createMenuItem("EXIT TO MAIN MENU", font);
        createMenuItem("EXIT GAME", font);

        updateMenuSelection();
    }
}
