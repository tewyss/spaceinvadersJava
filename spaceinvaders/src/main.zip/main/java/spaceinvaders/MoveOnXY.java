package spaceinvaders;

public interface MoveOnXY extends MoveOnX {
    double getY();
    void setY(double y);
}