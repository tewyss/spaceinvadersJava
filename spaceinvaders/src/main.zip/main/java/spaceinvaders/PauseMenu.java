package spaceinvaders;

import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class PauseMenu extends BaseMenu {

    public PauseMenu(Font font) {
        
        addTitle("GAME IS PAUSED", font, Color.rgb(200, 35, 200));
        createMenuItem("RESUME", font);
        createMenuItem("OPTIONS", font);
        createMenuItem("EXIT TO MAIN MENU", font);
        createMenuItem("EXIT GAME", font);
        
        updateMenuSelection();
    }
}