package spaceinvaders;

public interface MoveOnX {
    double getX();
    void setX(double x);
}