package spaceinvaders;

import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class OptionsMenu extends BaseMenu {
    private Text volumeText;
    private double volumeLevel;

    public OptionsMenu(Font font) {
        volumeLevel = Main.getSavedVolume();

        addTitle("OPTIONS", font, Color.BLUE);
        
        volumeText = new Text("VOLUME: " + (int) (volumeLevel * 100) + "%");
        volumeText.setFont(font);
        volumeText.setFill(Color.GREY);
        menuLayout.getChildren().add(volumeText);

        createMenuItem("PRESS ESC TO RETURN", font);
        updateVolumeText();
    }

    public void increaseVolume() {
        if (volumeLevel < 1.0) {
            volumeLevel = Math.min(1.0, Math.round((volumeLevel + 0.05) * 100.0) / 100.0);
        }
        updateVolumeText();
    }

    public void decreaseVolume() {
        if (volumeLevel > 0.0) {
            volumeLevel = Math.max(0.0, Math.round((volumeLevel - 0.05) * 100.0) / 100.0);
        }
        updateVolumeText();
    }

    private void updateVolumeText() {
        volumeText.setText("VOLUME: " + (int) (volumeLevel * 100) + "%");
    }

    public double getVolumeLevel() {
        return volumeLevel;
    }
}
