package spaceinvaders;

import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class VictoryMenu extends BaseMenu {

    public VictoryMenu(Font font, int currentScore) {
        addTitle("VICTORY ROYALE", font, Color.rgb(255, 236, 0));
        addScore("Your Score", currentScore, font);
        askPlayerNameAndSaveScore(currentScore);

        createMenuItem("EXIT TO MAIN MENU", font);
        createMenuItem("EXIT GAME", font);

        updateMenuSelection();
    }
}
