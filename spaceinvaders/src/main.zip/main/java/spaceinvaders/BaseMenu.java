package spaceinvaders;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import lombok.Getter;
import spaceinvaders.storage.HallOfFameManager;
import spaceinvaders.storage.PlayerScore;

public abstract class BaseMenu {
	@Getter
	protected VBox menuLayout;
	protected List<Text> menuItems;
	protected int indexOfSelection = 0;

	protected BaseMenu() {
		menuLayout = new VBox(30);
		menuItems = new ArrayList<>();
		menuLayout.setAlignment(Pos.CENTER);
		menuLayout.setStyle("-fx-background-color: black;");
	}

	protected void addTitle(String titleText, Font customFont, Color color) {
		Text title = new Text(titleText);
		title.setFont(Font.font(customFont.getFamily(), 40));
		title.setFill(color);
		menuLayout.getChildren().add(title);
	}

	protected void addScore(String labelText, int score, Font customFont) {
		Text scoreText = new Text(labelText + ": " + score);
		scoreText.setFont(Font.font(customFont.getFamily(), 30));
		scoreText.setFill(Color.WHITE);
		menuLayout.getChildren().add(scoreText);
	}

	protected void askPlayerNameAndSaveScore(int score) {
		if (score == 0) {
			return;
		}

		Platform.runLater(() -> {
			boolean asking = true;

			while (asking) {
				TextInputDialog dialog = new TextInputDialog("Player");
				dialog.setTitle("Enter Your Name");
				dialog.setHeaderText("Please enter your name (1-15 characters, only letters and numbers):");
				dialog.setContentText("Name:");

				Optional<String> result = dialog.showAndWait();

				if (result.isPresent()) {
					String playerName = result.get().trim();
					if (playerName.matches("[A-Za-z0-9]{1,15}")) {
						saveScore(playerName, score);
						asking = false;
					} else {
						Alert alert = new Alert(Alert.AlertType.WARNING);
						alert.setTitle("Invalid Name");
						alert.setHeaderText("Invalid input");
						alert.setContentText("Name must be 1-15 characters long and only contain letters and numbers.");
						alert.showAndWait();
					}
				} else {
					System.out.println("User canceled entering a name. Score not saved.");
					asking = false;
				}
			}
		});
	}

	protected void saveScore(String playerName, int score) {
		HallOfFameManager manager = new HallOfFameManager();
		manager.saveSingleScore(new PlayerScore(playerName, score));
		manager.close();
		System.out.println("Score saved: " + playerName + ", " + score);
	}

	protected void createMenuItem(String textContent, Font customFont) {
		Text menuItem = new Text(textContent);
		menuItem.setFont(customFont);
		menuItem.setFill(Color.WHITE);
		menuLayout.getChildren().add(menuItem);
		menuItems.add(menuItem);
	}

	protected void updateMenuSelection() {
		for (int i = 0; i < menuItems.size(); i++) {
			Text menuItem = menuItems.get(i);
			menuItem.setFill(i == indexOfSelection ? Color.rgb(30, 255, 0) : Color.WHITE);
		}
	}

	public void moveSelectionUp() {
		indexOfSelection = (indexOfSelection - 1 + menuItems.size()) % menuItems.size();
		updateMenuSelection();
	}

	public void moveSelectionDown() {
		indexOfSelection = (indexOfSelection + 1) % menuItems.size();
		updateMenuSelection();
	}

	public String getSelectedItem() {
		return menuItems.get(indexOfSelection).getText();
	}

	public VBox getLayout() {
		return menuLayout;
	}
}
