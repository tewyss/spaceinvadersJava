package spaceinvaders;

public class AlienShooterThread extends Thread {
    private final AlienManager alienManager;
    private volatile boolean running = true;

    public AlienShooterThread(AlienManager alienManager) {
        this.alienManager = alienManager;
    }

    public void terminate() {
        running = false;
    }

    @Override
    public void run() {
        while (running) {
            try {
                Thread.sleep(1000 + (int)(Math.random() * 2000)); // 1–3 sekundy
                synchronized (alienManager) {
                    alienManager.alienFireBullet();
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
