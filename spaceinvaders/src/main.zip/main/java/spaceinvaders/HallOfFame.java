package spaceinvaders;

import java.sql.SQLException;
import java.util.List;

import org.h2.tools.Server;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import lombok.extern.log4j.Log4j2;
import spaceinvaders.storage.HallOfFameManager;
import spaceinvaders.storage.PlayerScore;

@Log4j2
public class HallOfFame extends BaseMenu {
	private Server webServer;

	public HallOfFame(Font customFont) {
		addTitle("HALL OF FAME", customFont, Color.GOLD);

		HallOfFameManager manager = new HallOfFameManager();

		List<PlayerScore> scores = manager.loadScores();
		startH2WebServerToInspectDb();
		TableView<PlayerScore> tableView = createTableView(scores);

		menuLayout.getChildren().add(tableView);
		createMenuItem("PRESS ESC TO RETURN", customFont);

	}

	private TableView<PlayerScore> createTableView(List<PlayerScore> scores) {
		TableView<PlayerScore> tableView = new TableView<>();
		TableColumn<PlayerScore, String> nameColumn = new TableColumn<>("Player");
		nameColumn.setCellValueFactory(new PropertyValueFactory<>("playerName"));

		TableColumn<PlayerScore, Integer> scoreColumn = new TableColumn<>("Score");
		scoreColumn.setCellValueFactory(new PropertyValueFactory<>("playerScore"));

		tableView.getColumns().add(nameColumn);
		tableView.getColumns().add(scoreColumn);

		ObservableList<PlayerScore> data = FXCollections.observableArrayList(scores);
		tableView.setItems(data);

		nameColumn.setPrefWidth(200);
		nameColumn.setStyle("-fx-alignment: CENTER;");

		scoreColumn.setPrefWidth(200);
		scoreColumn.setStyle("-fx-alignment: CENTER;");

		tableView.setMaxWidth(405);

		return tableView;
	}

	private void startH2WebServerToInspectDb() {
		try {
			webServer = Server.createWebServer();
			webServer.start();
			log.info("H2 Web Console running at: " + webServer.getURL());
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void stopH2Server() {
		if (webServer != null && webServer.isRunning(false)) {
			webServer.stop();
			log.info("H2 Web Console stopped.");
		}
	}
}
